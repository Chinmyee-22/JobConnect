import mysql from 'mysql2';
import dotenv from 'dotenv';

dotenv.config();

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'JMS',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

export const db = pool.promise();

export const createDBConnection = async () => {
  try {
    const connection = await db.getConnection();
    
    // Test query to verify table structure
    const [result] = await connection.query(`
      SELECT * FROM admin_users_3nf LIMIT 1
    `);
    
    console.log('Database connected successfully');
    console.log('Sample user:', result[0]);
    
    connection.release();
  } catch (error) {
    console.error('Database connection failed:', error);
    throw error;
  }
}; 