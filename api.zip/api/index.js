import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import userRoutes from './routes/users.js';
import jobRolesRouter from './routes/jobRoles.js';
import applicationsRouter from './routes/applications.js';
import authRouter from './routes/auth.js';
import statsRouter from './routes/stats.js';
import analyticsRouter from './routes/analytics.js';
import { createDBConnection } from './config/database.js';

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// CORS configuration
app.use(cors({
  origin: ['http://localhost:5173', 'http://127.0.0.1:5173'],
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  credentials: true,
  optionsSuccessStatus: 200
}));

app.use(express.json());

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err.stack);
  res.status(500).json({ 
    error: 'Internal Server Error',
    message: err.message 
  });
});

// Routes
app.use('/api/auth', authRouter);
app.use('/api/users', userRoutes);
app.use('/api/job-roles', jobRolesRouter);
app.use('/api/applications', applicationsRouter);
app.use('/api/stats', statsRouter);
app.use('/api/analytics', analyticsRouter);

// Start server function
const startServer = async () => {
  try {
    await createDBConnection();
    app.listen(port, () => {
      console.log(`Server is running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

// Start the server
startServer(); 