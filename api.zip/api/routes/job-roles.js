// Get all jobs
router.get('/', async (req, res) => {
  try {
    const [jobs] = await db.query(`
      SELECT * FROM updated_job_postings_with_keywords__1_
    `);
    
    console.log('Total jobs found:', jobs.length); // Debug log
    res.json(jobs);
  } catch (error) {
    console.error('Error fetching jobs:', error);
    res.status(500).json({ error: 'Failed to fetch jobs' });
  }
}); 