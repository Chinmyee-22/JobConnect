import express from 'express';
import { db } from '../config/database.js';

const router = express.Router();

// Get all job roles
router.get('/', async (req, res) => {
  try {
    console.log('Fetching jobs from database...');
    const [rows] = await db.query(`
      SELECT 
        job_id,
        job_title,
        job_type,
        salary_range,
        posted_on,
        expire_on,
        zipcode,
        work_auth_id,
        category_id,
        employer_id,
        keyword_id,
        perks_id,
        0 as applicationCount
      FROM updated_job_postings_with_keywords__1_
    `);
    console.log('Fetched jobs:', rows.length);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching job roles:', error);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
});

// Get job role by ID
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT 
        job_id,
        job_title,
        job_type,
        salary_range,
        posted_on,
        expire_on,
        zipcode,
        work_auth_id,
        category_id,
        employer_id,
        keyword_id,
        perks_id,
        0 as applicationCount
      FROM updated_job_postings_with_keywords__1_
      WHERE job_id = ?
    `, [req.params.id]);
    
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Job role not found' });
    }
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching job role:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create new job role
router.post('/', async (req, res) => {
  try {
    const {
      job_title,
      job_type,
      salary_range,
      posted_on,
      expire_on,
      zipcode,
      work_auth_id,
      category_id,
      employer_id,
      keyword_id,
      perks_id
    } = req.body;

    const [result] = await db.query(`
      INSERT INTO updated_job_postings_with_keywords__1_
      (job_title, job_type, salary_range, posted_on, expire_on, zipcode, 
       work_auth_id, category_id, employer_id, keyword_id, perks_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      job_title,
      job_type,
      salary_range,
      posted_on,
      expire_on,
      zipcode || null,
      work_auth_id || null,
      category_id || null,
      employer_id || null,
      keyword_id || null,
      perks_id || null
    ]);

    const [newJob] = await db.query(`
      SELECT * FROM updated_job_postings_with_keywords__1_
      WHERE job_id = ?
    `, [result.insertId]);

    res.status(201).json(newJob[0]);
  } catch (error) {
    console.error('Error creating job:', error);
    res.status(500).json({ 
      error: 'Failed to create job',
      details: error.message 
    });
  }
});

// Update job role
router.put('/:id', async (req, res) => {
  const {
    job_title,
    job_type,
    salary_range,
    posted_on,
    expire_on,
    zipcode,
    skills,
    employer_id
  } = req.body;

  try {
    const [result] = await db.query(`
      UPDATE updated_job_postings_with_keywords__1_
      SET 
        job_title = ?,
        job_type = ?,
        salary_range = ?,
        posted_on = ?,
        expire_on = ?,
        zipcode = ?,
        skills = ?,
        employer_id = ?
      WHERE job_id = ?
    `, [job_title, job_type, salary_range, posted_on, expire_on, zipcode, skills, employer_id, req.params.id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Job role not found' });
    }

    const [updatedJob] = await db.query(`
      SELECT 
        job_id,
        job_title,
        job_type,
        salary_range,
        DATE_FORMAT(posted_on, '%Y-%m-%d') as posted_on,
        DATE_FORMAT(expire_on, '%Y-%m-%d') as expire_on,
        zipcode,
        skills,
        employer_id,
        application_count as applicationCount
      FROM updated_job_postings_with_keywords__1_
      WHERE job_id = ?
    `, [req.params.id]);

    res.json(updatedJob[0]);
  } catch (error) {
    console.error('Error updating job role:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete job role
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query(
      'DELETE FROM updated_job_postings_with_keywords__1_ WHERE job_id = ?',
      [req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Job role not found' });
    }

    res.json({ message: 'Job role deleted successfully' });
  } catch (error) {
    console.error('Error deleting job role:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Add this test endpoint
router.get('/test', async (req, res) => {
  try {
    const [result] = await db.query('SELECT COUNT(*) as count FROM updated_job_postings_with_keywords__1_');
    res.json({ 
      message: 'Database connection successful',
      totalJobs: result[0].count,
      dbConfig: {
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        database: process.env.DB_NAME
      }
    });
  } catch (error) {
    res.status(500).json({ 
      error: 'Database connection failed', 
      details: error.message,
      code: error.code
    });
  }
});

export default router; 