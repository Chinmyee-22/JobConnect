import express from 'express';
import { db } from '../config/database.js';

const router = express.Router();

// Get all applications with count
router.get('/', async (req, res) => {
  try {
    // Get applications with details
    const [applications] = await db.query(`
      SELECT 
        a.application_id,
        a.job_id,
        a.seeker_id,
        a.application_status,
        a.application_date,
        j.job_title,
        s.first_name,
        s.last_name,
        s.email
      FROM applications a
      LEFT JOIN updated_job_postings_with_keywords__1_ j ON CAST(a.job_id AS CHAR) = j.job_id
      LEFT JOIN job_seekers_updated s ON CAST(a.seeker_id AS CHAR) = s.seeker_id
      ORDER BY a.application_date DESC
    `);

    // Log the results for debugging
    console.log('Found applications:', applications);

    // Transform the data to match the expected format
    const formattedApplications = applications.map(app => ({
      ...app,
      application_status: app.application_status || 'Pending',
      application_date: app.application_date || new Date().toISOString().split('T')[0]
    }));

    res.json({
      total: formattedApplications.length,
      applications: formattedApplications
    });
  } catch (error) {
    console.error('Error fetching applications:', error);
    console.error('Error details:', error.message);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
});

// Search job seekers by name
router.get('/search', async (req, res) => {
  try {
    const { name } = req.query;
    if (!name) {
      return res.status(400).json({ error: 'Name parameter is required' });
    }

    const [seekers] = await db.query(`
      SELECT * FROM job_seekers_updated 
      WHERE first_name LIKE ? OR last_name LIKE ?
    `, [`%${name}%`, `%${name}%`]);

    res.json(seekers);
  } catch (error) {
    console.error('Error searching job seekers:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Submit new application
router.post('/', async (req, res) => {
  try {
    const {
      job_id,
      first_name,
      last_name,
      phone,
      email,
      zip_code,
      edu_level,
      exp_level,
      age,
      gender,
      schools
    } = req.body;

    // Start transaction
    await db.query('START TRANSACTION');

    try {
      // Generate IDs in the correct format
      const seeker_id = `S${String(Math.floor(1000 + Math.random() * 9000)).padStart(4, '0')}`;
      const work_auth_id = Math.floor(100 + Math.random() * 900);
      const application_id = `A${String(Math.floor(1000 + Math.random() * 9000)).padStart(4, '0')}`;

      // Insert into job_seekers_updated
      await db.query(`
        INSERT INTO job_seekers_updated 
        (seeker_id, zip_code, work_auth_id, first_name, last_name, phone, email, 
         edu_level, exp_level, age, gender, schools)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        seeker_id,
        zip_code,
        work_auth_id,
        first_name,
        last_name,
        phone,
        email,
        edu_level,
        exp_level,
        age,
        gender,
        schools
      ]);

      // Insert into applications
      await db.query(`
        INSERT INTO applications 
        (application_id, job_id, seeker_id, application_status, application_date)
        VALUES (?, ?, ?, ?, ?)
      `, [
        application_id,
        job_id,
        seeker_id,
        'Pending',
        new Date().toISOString().split('T')[0]
      ]);

      // Commit transaction
      await db.query('COMMIT');

      res.status(201).json({ 
        message: 'Application submitted successfully',
        application_id,
        seeker_id,
        work_auth_id
      });
    } catch (error) {
      // Rollback on error
      await db.query('ROLLBACK');
      throw error;
    }
  } catch (error) {
    console.error('Error submitting application:', error);
    res.status(500).json({ 
      error: 'Failed to submit application',
      details: error.message 
    });
  }
});

export default router; 