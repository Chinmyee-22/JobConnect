import express from 'express';
import { db } from '../config/database.js';

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    let analytics = {
      totalJobs: 0,
      jobCategories: [],
      jobTypeDistribution: [],
      locationStats: [],
      salaryRanges: [],
      applicationSuccess: { completed: 0, pending: 0, rejected: 0, rate: '0' },
      monthlyTrends: [],
      activeLocations: 0
    };

    // Get total jobs count
    try {
      const [totalJobs] = await db.query(`
        SELECT COUNT(DISTINCT job_id) as count
        FROM updated_job_postings_with_keywords__1_
      `);
      analytics.totalJobs = totalJobs[0].count || 0;
    } catch (error) {
      console.error('Error fetching total jobs:', error);
    }

    // Get job categories with counts
    try {
      const [jobCategories] = await db.query(`
        SELECT 
          COALESCE(uc.category_name, 'Other') as category_name,
          COUNT(DISTINCT j.job_id) as count
        FROM updated_job_postings_with_keywords__1_ j
        LEFT JOIN updated_job_categories uc ON j.category_id = uc.category_id
        WHERE j.job_id IS NOT NULL
        GROUP BY uc.category_name
        HAVING count > 0
        ORDER BY count DESC
      `);
      console.log('Job categories data:', jobCategories);
      analytics.jobCategories = jobCategories;
    } catch (error) {
      console.error('Error fetching job categories:', error);
    }

    // Get job types with actual counts
    try {
      const [jobTypes] = await db.query(`
        SELECT 
          COALESCE(job_type, 'Full Time') as job_type,
          COUNT(DISTINCT job_id) as count
        FROM updated_job_postings_with_keywords__1_
        WHERE job_id IS NOT NULL
        GROUP BY job_type
        ORDER BY count DESC
      `);
      analytics.jobTypeDistribution = jobTypes;
    } catch (error) {
      console.error('Error fetching job types:', error);
    }

    // Get application success rates
    try {
      const [applicationStatus] = await db.query(`
        SELECT 
          COUNT(*) as total,
          COUNT(CASE WHEN application_status IN ('Accepted', 'Rejected') THEN 1 END) as completed,
          COUNT(CASE WHEN application_status = 'Pending' OR application_status IS NULL THEN 1 END) as pending,
          COUNT(CASE WHEN application_status = 'Rejected' THEN 1 END) as rejected,
          COUNT(CASE WHEN application_status = 'Accepted' THEN 1 END) as accepted
        FROM applications
      `);
      
      const total = parseInt(applicationStatus[0].total) || 0;
      const completed = parseInt(applicationStatus[0].completed) || 0;
      const accepted = parseInt(applicationStatus[0].accepted) || 0;
      const rejected = parseInt(applicationStatus[0].rejected) || 0;
      
      analytics.applicationSuccess = {
        completed,
        pending: parseInt(applicationStatus[0].pending) || 0,
        rejected,
        accepted,
        rate: total > 0 ? ((accepted / total) * 100).toFixed(1) : '0'
      };

      // Update the total applications stats
      analytics.totalApplications = total;
      analytics.completedApplications = completed;
      analytics.pendingApplications = parseInt(applicationStatus[0].pending) || 0;

      console.log('Application status:', analytics.applicationSuccess);
    } catch (error) {
      console.error('Error fetching application status:', error);
    }

    // Get salary ranges with counts
    try {
      const [salaryRanges] = await db.query(`
        SELECT 
          CASE 
            WHEN salary_range IS NULL OR salary_range = '' THEN 'Not Specified'
            ELSE salary_range 
          END as range,
          COUNT(DISTINCT j.job_id) as count
        FROM updated_job_postings_with_keywords__1_ j
        GROUP BY range
        HAVING count > 0
        ORDER BY 
          CASE 
            WHEN range = 'Not Specified' THEN 999999
            ELSE count
          END DESC
      `);
      console.log('Salary ranges data:', salaryRanges);
      analytics.salaryRanges = salaryRanges;
    } catch (error) {
      console.error('Error fetching salary ranges:', error);
    }

    // Get monthly activity
    try {
      const [monthlyTrends] = await db.query(`
        WITH RECURSIVE months AS (
          SELECT DATE_FORMAT(NOW(), '%Y-%m') as month
          UNION ALL
          SELECT DATE_FORMAT(DATE_SUB(STR_TO_DATE(month, '%Y-%m'), INTERVAL 1 MONTH), '%Y-%m')
          FROM months
          WHERE month >= DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 5 MONTH), '%Y-%m')
        )
        SELECT 
          m.month,
          COALESCE(a.application_count, 0) as applications,
          COALESCE(j.job_count, 0) as jobs
        FROM months m
        LEFT JOIN (
          SELECT 
            DATE_FORMAT(application_date, '%Y-%m') as month,
            COUNT(DISTINCT application_id) as application_count
          FROM applications
          WHERE application_date IS NOT NULL
          GROUP BY month
        ) a ON m.month = a.month
        LEFT JOIN (
          SELECT 
            DATE_FORMAT(posted_on, '%Y-%m') as month,
            COUNT(DISTINCT job_id) as job_count
          FROM updated_job_postings_with_keywords__1_
          WHERE posted_on IS NOT NULL
          GROUP BY month
        ) j ON m.month = j.month
        ORDER BY m.month DESC
        LIMIT 6
      `);
      console.log('Monthly trends data:', monthlyTrends);
      analytics.monthlyTrends = monthlyTrends;
    } catch (error) {
      console.error('Error fetching monthly trends:', error);
    }

    // Get active locations count
    try {
      const [locations] = await db.query(`
        SELECT COUNT(DISTINCT zipcode) as count
        FROM updated_job_postings_with_keywords__1_
        WHERE zipcode IS NOT NULL
      `);
      analytics.activeLocations = locations[0].count || 0;
    } catch (error) {
      console.error('Error fetching locations:', error);
    }

    console.log('Analytics data:', analytics);
    res.json(analytics);

  } catch (error) {
    console.error('Analytics error:', error);
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
});

export default router; 