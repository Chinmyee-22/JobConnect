import express from 'express';
import { db } from '../config/database.js';

const router = express.Router();

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log('Login attempt for:', email);

    // Check for admin login
    if (email === 'naik.ameya@hotmail.com') {
      if (password !== 'JobConnect1') {
        return res.status(401).json({ message: 'Invalid admin credentials' });
      }
      return res.json({
        message: 'Login successful',
        user: {
          user_id: 0,
          name: 'Admin',
          email: 'naik.ameya@hotmail.com',
          status: 'active'
        }
      });
    }

    // Regular user login
    const [users] = await db.query(`
      SELECT user_id, name, email, status 
      FROM admin_users_3nf 
      WHERE email = ?
    `, [email]);

    console.log('Found users:', users);

    if (users.length === 0) {
      return res.status(401).json({ message: 'User not found' });
    }

    // For regular users, check the standard password
    if (password !== 'JobConnect') {
      return res.status(401).json({ message: 'Invalid password' });
    }

    const user = users[0];

    // Update last login
    try {
      await db.query(`
        UPDATE admin_users_3nf 
        SET last_login = ? 
        WHERE user_id = ?
      `, [new Date().toISOString().split('T')[0], user.user_id]);
    } catch (updateError) {
      console.error('Error updating last_login:', updateError);
      // Continue even if update fails
    }

    // Send response
    res.json({ 
      message: 'Login successful',
      user: {
        user_id: user.user_id,
        name: user.name || email.split('@')[0], // Fallback name if not set
        email: user.email,
        status: user.status || 'active'
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ 
      message: 'Login failed',
      details: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});

// Register
router.post('/register', async (req, res) => {
  try {
    const { name, email } = req.body;

    // Check if email already exists
    const [existing] = await db.query(
      'SELECT * FROM admin_users_3nf WHERE email = ?',
      [email]
    );

    if (existing.length > 0) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    // Generate new user_id
    const [maxId] = await db.query('SELECT MAX(user_id) as max FROM admin_users_3nf');
    const newUserId = (maxId[0].max || 1000) + 1;

    // Insert new user
    await db.query(`
      INSERT INTO admin_users_3nf 
      (user_id, name, email, status, registration_date, last_login)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [
      newUserId,
      name,
      email,
      'active',
      new Date().toISOString().split('T')[0],
      new Date().toISOString().split('T')[0]
    ]);

    res.status(201).json({ message: 'Registration successful' });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Registration failed' });
  }
});

// Add this test endpoint to verify database connection
router.get('/test-db', async (req, res) => {
  try {
    const [users] = await db.query('SELECT * FROM admin_users_3nf LIMIT 1');
    res.json({ 
      message: 'Database connection successful',
      sampleUser: users[0] ? {
        user_id: users[0].user_id,
        email: users[0].email
      } : null
    });
  } catch (error) {
    console.error('Database test error:', error);
    res.status(500).json({ 
      message: 'Database connection failed',
      error: error.message 
    });
  }
});

export default router; 