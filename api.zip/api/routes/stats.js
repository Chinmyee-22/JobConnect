import express from 'express';
import { db } from '../config/database.js';

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    // Get total applications with error handling
    let totalApps = 0;
    try {
      const [totalResult] = await db.query(`
        SELECT COUNT(*) as count FROM applications
      `);
      totalApps = totalResult[0]?.count || 0;
      console.log('Total applications:', totalApps);
    } catch (error) {
      console.error('Error counting applications:', error);
    }

    // Get active jobs count
    let activeJobs = 0;
    try {
      // Get all jobs from the same table as job listings
      const [activeResult] = await db.query(`
        SELECT COUNT(job_id) as count 
        FROM updated_job_postings_with_keywords__1_
      `);
      
      activeJobs = activeResult[0]?.count || 0;
      console.log('Active jobs count:', activeJobs);
    } catch (error) {
      console.error('Error counting active jobs:', error);
    }

    // Get applications by status
    let pendingApps = 0;
    let completedApps = 0;
    try {
      const [statusResult] = await db.query(`
        SELECT 
          COUNT(CASE WHEN application_status = 'Pending' OR application_status IS NULL THEN 1 END) as pending,
          COUNT(CASE WHEN application_status = 'Completed' THEN 1 END) as completed
        FROM applications
      `);
      pendingApps = statusResult[0]?.pending || 0;
      completedApps = statusResult[0]?.completed || 0;
      console.log('Application status:', { pending: pendingApps, completed: completedApps });
    } catch (error) {
      console.error('Error counting application status:', error);
    }

    // Get job categories
    let jobCategories = [];
    try {
      const [categoriesResult] = await db.query(`
        SELECT 
          COALESCE(c.category_name, 'Other') as category_name,
          COUNT(j.job_id) as count
        FROM updated_job_postings_with_keywords__1_ j
        LEFT JOIN job_categories c ON j.category_id = c.category_id
        GROUP BY c.category_name
        HAVING count > 0
        ORDER BY count DESC
      `);
      jobCategories = categoriesResult;
      console.log('Job categories:', jobCategories);
    } catch (error) {
      console.error('Error getting job categories:', error);
    }

    // Get application trends
    let applicationTrends = [];
    try {
      const [trendsResult] = await db.query(`
        SELECT 
          DATE(application_date) as date,
          COUNT(*) as count
        FROM applications
        WHERE application_date IS NOT NULL
        GROUP BY DATE(application_date)
        ORDER BY date DESC
        LIMIT 7
      `);
      applicationTrends = trendsResult;
      console.log('Application trends:', applicationTrends);
    } catch (error) {
      console.error('Error getting application trends:', error);
    }

    // Send response with all available data
    res.json({
      totalApplications: totalApps,
      activeJobs: activeJobs,
      pendingApplications: pendingApps,
      completedApplications: completedApps,
      jobCategories: jobCategories,
      applicationTrends: applicationTrends
    });

  } catch (error) {
    console.error('Error in stats endpoint:', error);
    res.status(500).json({ 
      error: 'Failed to fetch stats',
      details: error.message
    });
  }
});

export default router; 